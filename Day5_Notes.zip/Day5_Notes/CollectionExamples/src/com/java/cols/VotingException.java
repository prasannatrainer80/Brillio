package com.java.cols;

public class VotingException extends Exception {
	public VotingException(String error) {
		super(error);
	}
}
