package com.java.cols;

public class NumberZeroException extends Exception {

	NumberZeroException(String error) {
		super(error);
	}
}
