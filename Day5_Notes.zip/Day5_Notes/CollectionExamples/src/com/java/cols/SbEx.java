package com.java.cols;

public class SbEx {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Hi\n");
		sb.append("Hello");
		System.out.println(sb);
	}
}
