package com.java.cols;

public class NegativeException extends Exception {

	NegativeException(String error) {
		super(error);
	}
}
