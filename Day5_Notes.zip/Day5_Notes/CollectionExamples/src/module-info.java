/**
 * 
 */
/**
 * 
 */
module CollectionExamples {
}