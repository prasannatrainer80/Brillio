package com.java.day2;

public class Test {

	public static void main(String[] args) {
//		String s1="Subash", s2="Manjunth",s3="Sujith";
//		String s4="Suni",s5="Sunitha";
//		System.out.println(s1.compareTo(s2));
//		System.out.println(s1.compareTo(s3));
//		System.out.println(s4.compareTo(s5));
//		System.out.println(s5.compareTo(s4));
		
		String s1="Lewis",s2="Lee",s3="Lewis";
		System.out.println(s1.equals(s3));
		System.out.println(s2.equals(s3));
		System.out.println(s1.compareTo(s2));
	}
}
