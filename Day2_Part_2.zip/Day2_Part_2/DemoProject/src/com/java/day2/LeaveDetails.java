package com.java.day2;

public class LeaveDetails {

	int empId;
	int noOfDays;
	LeaveType leaveType;
	LeaveStatus leaveStatus;
	String leaveReason;
	String managerComments;
	
	
}
