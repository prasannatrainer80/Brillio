package com.java.day2;

public enum LeaveType {
	EL, PL, ML
}
