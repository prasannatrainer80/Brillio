package com.java.day2;

public class Agent {

	int agentId;
	String agentName;
	Gender gender;
	double premium;
	@Override
	public String toString() {
		return "Agent [agentId=" + agentId + ", agentName=" + agentName + ", gender=" + gender + ", premium=" + premium
				+ "]";
	}
	
	
}
