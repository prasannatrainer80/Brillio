package com.java.day2;

public enum Gender {
	MALE, FEMALE
}
