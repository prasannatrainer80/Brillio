package com.java.day2;

public enum LeaveStatus {
	PENDING, ACCEPTED, REJECTED
}
