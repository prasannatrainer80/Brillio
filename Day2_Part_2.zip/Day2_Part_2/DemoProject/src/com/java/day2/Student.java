package com.java.day2;

public class Student {

	int sid;
	String name;
	String city;
	double cgpa;
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", city=" + city + ", cgpa=" + cgpa + "]";
	}
	
	
}
