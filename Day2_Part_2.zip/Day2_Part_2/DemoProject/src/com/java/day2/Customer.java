package com.java.day2;

public class Customer {

	int custId;
	String custName;
	double premium;
}
