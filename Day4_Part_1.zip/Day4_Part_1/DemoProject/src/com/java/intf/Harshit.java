package com.java.intf;

public class Harshit implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Harshit...");
	}

	@Override
	public void email() {
		System.out.println("Email is harshit@gmail.com...");
	}

}
