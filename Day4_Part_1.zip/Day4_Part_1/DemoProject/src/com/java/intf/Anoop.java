package com.java.intf;

public class Anoop implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Anoop...");
	}

	@Override
	public void email() {
		System.out.println("Email is Anoop@gmail.com");
	}

}
