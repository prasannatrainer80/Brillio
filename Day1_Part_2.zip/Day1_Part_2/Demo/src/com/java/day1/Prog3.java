package com.java.day1;

public class Prog3 {

	public static void main(String[] args) {
		char ch='A';
		System.out.println(ch);
		ch++;
		System.out.println(ch);
	}
}
