package com.java.day1;

public class Demo {

	public void company() {
		System.out.println("Company is Brillio");
	}
	
	void topic() {
		System.out.println("Topic is Java Fullstack...");
	}
	
	private void trainer() {
		System.out.println("Trainer is Prasanna...");
	}
}
