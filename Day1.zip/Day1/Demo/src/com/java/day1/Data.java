package com.java.day1;

public class Data {
//	int a;
//	static int score;
	public static void main(String[] args) {
		Demo demo = new Demo();
		demo.company();
		demo.topic();
	}
}
