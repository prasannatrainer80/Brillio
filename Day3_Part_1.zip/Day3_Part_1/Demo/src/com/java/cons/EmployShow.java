package com.java.cons;

public class EmployShow {

	public static void main(String[] args) {
		Employ employ1 = new Employ(1, "Anoop", 99234.22);
		System.out.println(employ1);
	}
}
