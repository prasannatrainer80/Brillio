package com.java.fin;

//final class Test {
//	
//}
//
//class Hello extends Test {
//	
//}

//class First {
//	final void policy() {
//		
//	}
//}
//
//class Second extends First {
//	void policy() {
//		
//	}
//}

//class Test {
//	final String company="Brillio";
//	
//	void show() {
//		company = "Brillio Ltd";
//	}
//}
public class FinEx {

	public static void main(String[] args) {
		
	}
}



