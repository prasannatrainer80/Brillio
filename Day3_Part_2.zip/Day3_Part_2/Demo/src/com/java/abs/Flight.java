package com.java.abs;

public abstract class Flight {

	public abstract void idProof();
	public abstract void ticket();
}
