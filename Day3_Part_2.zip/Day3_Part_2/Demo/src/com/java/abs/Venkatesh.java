package com.java.abs;

public class Venkatesh extends Flight {

	@Override
	public void idProof() {
		System.out.println("Venkatesh Taking Aadhar as Id Proof...");
		
	}

	@Override
	public void ticket() {
		System.out.println("Venkatesh Taking First Class Ticket for Travel...");
	}

}
