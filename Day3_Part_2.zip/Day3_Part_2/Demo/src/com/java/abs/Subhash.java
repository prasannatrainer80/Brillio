package com.java.abs;

public class Subhash extends Flight {

	@Override
	public void idProof() {
		System.out.println("Subhash Taking driving liscence as Id Proof...");
		
	}

	@Override
	public void ticket() {
		System.out.println("Subhash Taking Business Class Ticket for Travel...");
	}

}
