package com.java.abs;

public class Crocodile extends Animal {

	@Override
	public void name() {
		System.out.println("Name is Crocodile...");
	}

	@Override
	public void type() {
		System.out.println("Its Water Animal...");
	}

}
