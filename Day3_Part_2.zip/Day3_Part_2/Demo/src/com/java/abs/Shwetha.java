package com.java.abs;

public class Shwetha extends Flight {

	@Override
	public void idProof() {
		System.out.println("Shwetha Taking Passport as Idproof for Travel...");
	}

	@Override
	public void ticket() {
		System.out.println("Shwetha taking Economy class ticket for Travel...");
	}

}
