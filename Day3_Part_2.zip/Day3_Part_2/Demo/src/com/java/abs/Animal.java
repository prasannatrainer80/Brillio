package com.java.abs;

public abstract class Animal {

	public abstract void name();
	public abstract void type();
}
