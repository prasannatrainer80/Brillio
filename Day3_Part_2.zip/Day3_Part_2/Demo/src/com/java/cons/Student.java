package com.java.cons;

public class Student {

	int sid;
	String sname;
	String city;
	double cgpa;
	
	
}
