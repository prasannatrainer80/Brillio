package com.java.p1;

public class Test {

	public void show() {
		Demo demo = new Demo();
		System.out.println(demo.friendlyString);
		System.out.println(demo.protectedString);
		System.out.println(demo.publicString);
	}
}
