package com.java.p2;

import com.java.p1.Demo;

public class Testing {

	public void show() {
		Demo demo = new Demo();
		System.out.println(demo.publicString);
	}
}
