package com.java.cols;

public class DateEx1 {

}
