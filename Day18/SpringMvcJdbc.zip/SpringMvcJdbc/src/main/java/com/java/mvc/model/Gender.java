package com.java.mvc.model;

public enum Gender {
	MALE, FEMALE
}
