import { render, screen } from "@testing-library/react";
import Test from "./Test";

it("Test Component Heading Checking ", () => {
    render(<Test />);
    expect(screen.getByText('Welcome to React Testing')).toBeInTheDocument();
})

test('null', () => {
    const n = null;
    expect(n).toBeNull();
    expect(n).toBeDefined();
    expect(n).not.toBeUndefined();
    expect(n).not.toBeTruthy();
    expect(n).toBeFalsy();
  });
  
  test('zero', () => {
    const z = 0;
    expect(z).not.toBeNull();
    expect(z).toBeDefined();
    expect(z).not.toBeUndefined();
    expect(z).not.toBeTruthy();
    expect(z).toBeFalsy();
  });