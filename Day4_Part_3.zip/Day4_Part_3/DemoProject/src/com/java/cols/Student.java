package com.java.cols;

public class Student {

	private int sid;
	private String sname;
	private String city;
	private double cgp;
	
	
}
