package com.java.day2;

public class ArrayDemo4 {

	public void show() {
		String[] names = {"Mounika","Natraj","Poojitha","Rakshitha","Srinath","Srihari","Manoj"};
		for (String s : names) {
			System.out.println(s);
		}
	}
	public static void main(String[] args) {
		new ArrayDemo4().show();
	}
}
