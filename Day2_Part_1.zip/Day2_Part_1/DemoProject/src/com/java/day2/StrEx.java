package com.java.day2;

public class StrEx {

	public static void main(String[] args) {
		String s1="Natraj",s2="Srihari",s3="Dinesh",s4="Natraj";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
