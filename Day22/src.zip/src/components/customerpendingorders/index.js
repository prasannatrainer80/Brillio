import customerpendingorders from "./customerpendingorders"
export default customerpendingorders;
