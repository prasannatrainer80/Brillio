import React, {Component} from 'react';
// import './customerpendingorders.scss'
// import { connect } from "react-redux";
// import { bindActionCreators } from "redux";
// import * as customerpendingordersActions from "../../store/customerpendingorders/actions";
export default class customerpendingorders extends Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {};
    // }
    render() {
      return <div className="component-customerpendingorders">Hello! component customerpendingorders</div>;
    }
  }
// export default connect(
//     ({ customerpendingorders }) => ({ ...customerpendingorders }),
//     dispatch => bindActionCreators({ ...customerpendingordersActions }, dispatch)
//   )( customerpendingorders );