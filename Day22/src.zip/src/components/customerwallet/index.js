import customerwallet from "./customerwallet"
export default customerwallet;
