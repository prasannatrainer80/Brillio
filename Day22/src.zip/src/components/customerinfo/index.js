import customerinfo from "./customerinfo"
export default customerinfo;
