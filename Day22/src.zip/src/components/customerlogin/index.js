import customerlogin from "./customerlogin"
export default customerlogin;
